<footer class="main-footer">

	<strong>Copyright © <?php echo date("Y"); ?>  <a href="<?php echo $ruta; ?>" target="_blank">CRM Gamarra 2020</a>.</strong> Todos los derechos reservados.

</footer>