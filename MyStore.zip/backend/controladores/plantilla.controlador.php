<?php

class ControladorPlantilla{

	/*=============================================
	Método que incluye la plantilla
	=============================================*/
	public function ctrPlantilla(){

		include "vistas/plantilla.php";
	}	

}