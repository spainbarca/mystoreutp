<?php

class ControladorRuta{

	static public function ctrRuta(){

		return "http://localhost:8083/MyStore/";

	}

	static public function ctrRutaBackend(){

		return "http://localhost:8083/MyStore/backend/";

	}

}