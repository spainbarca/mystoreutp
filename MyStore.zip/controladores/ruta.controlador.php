<?php

class ControladorRuta{

	static public function ctrRuta(){

		return "http://localhost:8083/MyStore/";

	}

	static public function ctrServidor(){

		return "http://localhost:8083/MyStore/backend/";
	}

}